from __future__ import annotations

from decimal import Decimal
from typing import Any

from agent.services.database import db


def _to_json_value(value: Any) -> Any:
    """Convert PostgreSQL numeric values to JSON-safe primitives."""
    if isinstance(value, Decimal):
        return float(value)
    return value


def _fetch_one(
    query: str,
    params: tuple[Any, ...] = (),
) -> dict[str, Any] | None:
    """
    Execute one predefined, read-only SQL query through the project's
    Database abstraction.

    Do NOT create/close raw psycopg connections here. The application
    already owns connection pooling in agent.services.database.
    """
    row = db.fetch_one(query, list(params))
    if row is None:
        return None
    return {key: _to_json_value(value) for key, value in row.items()}


def _fetch_all(
    query: str,
    params: tuple[Any, ...] = (),
) -> list[dict[str, Any]]:
    """Execute one predefined, read-only SQL query via the shared DB pool."""
    rows = db.fetch_all(query, list(params))
    return [
        {key: _to_json_value(value) for key, value in row.items()}
        for row in rows
    ]


def invoice_details(invoice_id: str) -> dict[str, Any] | None:
    """Retrieve the current persisted audit record for one invoice."""
    return _fetch_one(
        """
        SELECT
            invoice_id,
            invoice_number,
            vendor_name,
            po_number,
            invoice_date,
            currency,
            subtotal_amount,
            tax_amount,
            tax_rate,
            total_amount,
            validation_status,
            recommendation
        FROM audit.invoices
        WHERE invoice_id = %s
        LIMIT 1
        """,
        (invoice_id,),
    )


def invoice_discrepancies(invoice_id: str) -> list[dict[str, Any]]:
    """Return currently open discrepancies for one invoice."""
    return _fetch_all(
        """
        SELECT
            discrepancy_type,
            severity,
            message,
            details,
            status
        FROM audit.discrepancies
        WHERE invoice_id = %s
          AND UPPER(status) = 'OPEN'
        ORDER BY id
        """,
        (invoice_id,),
    )


def invoice_line_items(invoice_id: str) -> list[dict[str, Any]]:
    """Return effective persisted line items for one invoice."""
    return _fetch_all(
        """
        SELECT
            line_number,
            sku,
            description,
            quantity,
            unit_price,
            line_total,
            source
        FROM audit.invoice_line_items
        WHERE invoice_id = %s
        ORDER BY line_number
        """,
        (invoice_id,),
    )


def invoice_summary(invoice_id: str) -> dict[str, Any]:
    """Build a controlled structured answer payload for one invoice."""
    invoice = invoice_details(invoice_id)

    if invoice is None:
        return {
            "found": False,
            "invoice_id": invoice_id,
            "message": "Invoice not found.",
        }

    return {
        "found": True,
        "invoice": invoice,
        "discrepancies": invoice_discrepancies(invoice_id),
        "line_items": invoice_line_items(invoice_id),
    }


def list_invoices(limit: int = 20) -> list[dict[str, Any]]:
    """
    Return recent invoices.

    The limit is converted to an integer and clamped before being
    interpolated into the fixed SQL statement. No user SQL is accepted.
    """
    limit = max(1, min(int(limit), 100))

    return _fetch_all(
        f"""
        SELECT
            invoice_id,
            invoice_number,
            vendor_name,
            po_number,
            invoice_date,
            currency,
            total_amount,
            validation_status,
            recommendation
        FROM audit.invoices
        ORDER BY created_at DESC
        LIMIT {limit}
        """
    )


def answer_structured_question(
    question: str,
    invoice_id: str | None = None,
) -> dict[str, Any]:
    """
    Answer supported structured questions using predefined SQL only.

    User text is interpreted as intent; it is never concatenated into SQL.
    """
    question_lower = question.lower().strip()

    if not question_lower:
        return {
            "answer": "Question cannot be empty.",
            "data": {},
        }

    if invoice_id:
        summary = invoice_summary(invoice_id)

        if not summary["found"]:
            return {
                "answer": summary["message"],
                "data": summary,
            }

        invoice = summary["invoice"]

        if any(
            word in question_lower
            for word in ("discrepanc", "mismatch", "difference")
        ):
            discrepancies = summary["discrepancies"]
            if not discrepancies:
                answer = f"Invoice {invoice_id} has no recorded discrepancies."
            else:
                answer = (
                    f"Invoice {invoice_id} has "
                    f"{len(discrepancies)} recorded discrepancies."
                )
            return {
                "answer": answer,
                "data": discrepancies,
            }

        if any(
            word in question_lower
            for word in ("line", "sku", "item")
        ):
            return {
                "answer": (
                    f"Invoice {invoice_id} contains "
                    f"{len(summary['line_items'])} line items."
                ),
                "data": summary["line_items"],
            }

        if any(
            word in question_lower
            for word in ("total", "amount", "value")
        ):
            total = invoice.get("total_amount")
            currency = invoice.get("currency") or ""
            return {
                "answer": f"Invoice {invoice_id} total is {currency} {total}.".strip(),
                "data": {
                    "invoice_id": invoice_id,
                    "total_amount": total,
                    "currency": currency,
                },
            }

        if any(
            word in question_lower
            for word in ("status", "state")
        ):
            validation_status = invoice.get("validation_status")
            return {
                "answer": (
                    f"Invoice {invoice_id} validation status is "
                    f"{validation_status}."
                ),
                "data": {
                    "invoice_id": invoice_id,
                    "validation_status": validation_status,
                },
            }

        if any(
            word in question_lower
            for word in ("recommendation", "decision")
        ):
            recommendation = invoice.get("recommendation")
            return {
                "answer": (
                    f"Invoice {invoice_id} recommendation is "
                    f"{recommendation}."
                ),
                "data": {
                    "invoice_id": invoice_id,
                    "recommendation": recommendation,
                },
            }

        if any(
            word in question_lower
            for word in ("vendor", "supplier")
        ):
            vendor = invoice.get("vendor_name")
            return {
                "answer": f"Invoice {invoice_id} vendor is {vendor}.",
                "data": {
                    "invoice_id": invoice_id,
                    "vendor_name": vendor,
                },
            }

        if "purchase order" in question_lower or re_word_po(question_lower):
            po_number = invoice.get("po_number")
            return {
                "answer": (
                    f"Invoice {invoice_id} references PO {po_number}."
                ),
                "data": {
                    "invoice_id": invoice_id,
                    "po_number": po_number,
                },
            }

        return {
            "answer": f"Invoice {invoice_id} was found.",
            "data": summary,
        }

    invoices = list_invoices()

    if not invoices:
        return {
            "answer": "No invoices were found.",
            "data": [],
        }

    return {
        "answer": f"Found {len(invoices)} recent invoices.",
        "data": invoices,
    }


def re_word_po(question: str) -> bool:
    """Return True when the standalone token 'po' occurs in a question."""
    import re
    return bool(re.search(r"\bpo\b", question))


def sql_answer_state(state: dict[str, Any]) -> dict[str, Any]:
    """LangGraph adapter for the structured SQL branch."""
    question = str(state.get("rag_question") or "").strip()
    filters = state.get("rag_filters") or {}
    invoice_id = filters.get("invoice_id")

    try:
        result = answer_structured_question(
            question=question,
            invoice_id=str(invoice_id) if invoice_id else None,
        )
        return {
            "rag_answer": result["answer"],
            "rag_sql_result": result["data"],
            "rag_answer_accepted": True,
            "rag_score": 1.0,
        }
    except Exception as exc:
        return {
            "rag_answer": "Unable to answer the structured question.",
            "rag_sql_result": {},
            "rag_answer_accepted": False,
            "warnings": [
                *list(state.get("warnings") or []),
                f"Structured SQL query failed: {exc}",
            ],
        }
