"""
Central settings for the agent.

* Connection details and model names come from environment variables
  (supplied at runtime by docker compose via env_file - never baked in).
* Business rules come from config/rules.yaml.
* Prompt templates and personas come from config/prompts.yaml.
"""

import logging
import os
import sys
from pathlib import Path

import yaml

APP_ROOT = Path(__file__).resolve().parent.parent          # /app inside the container
CONFIG_DIR = Path(os.environ.get("CONFIG_DIR", APP_ROOT / "config"))


def _load_yaml(file_name: str) -> dict:
    with open(CONFIG_DIR / file_name, encoding="utf-8") as handle:
        return yaml.safe_load(handle)


RULES = _load_yaml("rules.yaml")
PROMPTS = _load_yaml("prompts.yaml")

# ---------------------------------------------------------------
# Services inside the compose network (service names, container ports)
# ---------------------------------------------------------------
POSTGRES_HOST = os.environ.get("POSTGRES_HOST", "postgres")
POSTGRES_PORT = os.environ.get("POSTGRES_PORT", "5432")
POSTGRES_DB = os.environ.get("POSTGRES_DB", "invoice_auditor")
POSTGRES_USER = os.environ.get("POSTGRES_USER", "")
POSTGRES_PASSWORD = os.environ.get("POSTGRES_PASSWORD", "")

REDIS_URL = os.environ.get("REDIS_URL", "redis://redis:6379/0")
QDRANT_URL = os.environ.get("QDRANT_URL", "http://qdrant:6333")
ERP_BASE_URL = os.environ.get("ERP_BASE_URL", "http://mock-erp:8000")

# ---------------------------------------------------------------
# Folders (mounted volumes)
# ---------------------------------------------------------------
INCOMING_DIR = Path(os.environ.get("INCOMING_DIR", APP_ROOT / "data" / "incoming"))
REPORTS_DIR = Path(os.environ.get("REPORTS_DIR", APP_ROOT / RULES["reporting"]["output_dir"]))
POLL_INTERVAL_SECONDS = int(os.environ.get("POLL_INTERVAL_SECONDS", "10"))
SUPPORTED_EXTENSIONS = {".pdf": "pdf", ".docx": "docx", ".png": "image",
                        ".jpg": "image", ".jpeg": "image"}

# Tesseract language packs needed by the dataset (English, Spanish, German)
OCR_LANGUAGES = os.environ.get("OCR_LANGUAGES", "eng+spa+deu")

# ---------------------------------------------------------------
# Models (AWS Bedrock through LiteLLM). AWS credentials are read by
# LiteLLM/boto3 straight from the environment.
# ---------------------------------------------------------------
def model_setting(env_name: str, default: str) -> str:
    """
    Read a model name from the environment.
    * an empty value (e.g. "RAG_MODEL=") falls back to the default
    * LiteLLM needs the "bedrock/" prefix to route the call to AWS Bedrock,
      so we add it when it is missing ("amazon.nova-lite-v1:0" -> "bedrock/amazon.nova-lite-v1:0")
    """
    value = (os.environ.get(env_name) or "").strip() or default
    return value if value.startswith("bedrock/") else f"bedrock/{value}"


REASONING_MODEL = model_setting("REASONING_MODEL", "bedrock/amazon.nova-lite-v1:0")
RAG_MODEL = model_setting("RAG_MODEL", "bedrock/cohere.command-r-plus-v1:0")
TRANSLATION_MODEL = model_setting("TRANSLATION_MODEL", "bedrock/cohere.command-r-plus-v1:0")
EMBEDDING_MODEL = model_setting("EMBEDDING_MODEL", "bedrock/amazon.titan-embed-text-v2:0")
EMBEDDING_DIMENSIONS = int(os.environ.get("EMBEDDING_DIMENSIONS") or "1024")

# ---------------------------------------------------------------
# Cache / RAG settings
# ---------------------------------------------------------------
LLM_CACHE_TTL_SECONDS = int(os.environ.get("LLM_CACHE_TTL_SECONDS", str(7 * 24 * 3600)))
ANSWER_CACHE_TTL_SECONDS = int(os.environ.get("ANSWER_CACHE_TTL_SECONDS", "3600"))
QDRANT_COLLECTION = os.environ.get("QDRANT_COLLECTION", "invoice_chunks")
RAG_PASS_SCORE = 0.7        # problem statement: show answer if avg triad score > 0.7
RAG_MAX_RETRIES = 3         # problem statement: max 3 retries

# ---------------------------------------------------------------
# Logging - always stdout (containers must not log to files)
# ---------------------------------------------------------------
logging.basicConfig(
    stream=sys.stdout,
    level=RULES.get("logging", {}).get("log_level", "INFO"),
    format="%(asctime)s [agent] %(levelname)s %(name)s: %(message)s",
)


def postgres_conninfo() -> str:
    return (
        f"host={POSTGRES_HOST} port={POSTGRES_PORT} dbname={POSTGRES_DB} "
        f"user={POSTGRES_USER} password={POSTGRES_PASSWORD}"
    )
