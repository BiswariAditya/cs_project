"""
Translation Agent (LLM: Cohere Command R+ on Bedrock).

Detects the source language, translates to English and records a confidence
score. Results are cached in Redis by the LLM client, so the same content is
never translated twice.
"""

from app.services.llm_client import ask_llm_json, persona, prompt
from app.settings import TRANSLATION_MODEL


def translate_invoice(raw_text: str, language_hint: str | None = None) -> dict:
    hint = ""
    if language_hint:
        hint = f"- The email header suggests the language is '{language_hint}', but verify it yourself."

    result = ask_llm_json(
        TRANSLATION_MODEL,
        persona("translator"),
        prompt("translate", text=raw_text, language_hint=hint),
        max_tokens=4000,
    )

    language = str(result.get("source_language") or "unknown").lower()[:8]
    confidence = float(result.get("confidence") or 0.0)
    translated = result.get("translated_text") or raw_text

    # English text needs no translation - keep the original exactly.
    if language == "en":
        translated, confidence = raw_text, 1.0

    return {
        "source_language": language,
        "translation_confidence": max(0.0, min(confidence, 1.0)),
        "translated_text": translated,
    }
